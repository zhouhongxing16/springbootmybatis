-- --------------------------------------------------------
-- 主机:                           192.168.3.127
-- 服务器版本:                        5.7.18 - MySQL Community Server (GPL)
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 导出 scyyxh_wx 的数据库结构
DROP DATABASE IF EXISTS `scyyxh_wx`;
CREATE DATABASE IF NOT EXISTS `scyyxh_wx` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `scyyxh_wx`;

-- 导出  表 scyyxh_wx.kb_conferences 结构
DROP TABLE IF EXISTS `kb_conferences`;
CREATE TABLE IF NOT EXISTS `kb_conferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `hold_place` varchar(100) DEFAULT NULL,
  `hold_unit` varchar(100) DEFAULT NULL,
  `do_unit` varchar(100) DEFAULT NULL,
  `ass_unit` varchar(100) DEFAULT NULL,
  `pic_url` varchar(200) DEFAULT NULL,
  `brief` varbinary(1000) DEFAULT NULL,
  `qrcode` varchar(300) DEFAULT NULL,
  `reg_start` varchar(20) DEFAULT NULL,
  `reg_end` varchar(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议表';

-- 正在导出表  scyyxh_wx.kb_conferences 的数据：~0 rows (大约)
DELETE FROM `kb_conferences`;
/*!40000 ALTER TABLE `kb_conferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conferences` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_conference_agenda 结构
DROP TABLE IF EXISTS `kb_conference_agenda`;
CREATE TABLE IF NOT EXISTS `kb_conference_agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conference_id` int(11) NOT NULL,
  `hold_date` varchar(20) DEFAULT NULL,
  `start_time` varchar(10) DEFAULT NULL,
  `end_time` varchar(10) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `guest_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议实际议程';

-- 正在导出表  scyyxh_wx.kb_conference_agenda 的数据：~0 rows (大约)
DELETE FROM `kb_conference_agenda`;
/*!40000 ALTER TABLE `kb_conference_agenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conference_agenda` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_conference_category 结构
DROP TABLE IF EXISTS `kb_conference_category`;
CREATE TABLE IF NOT EXISTS `kb_conference_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `keywords` varchar(200) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议主题分类';

-- 正在导出表  scyyxh_wx.kb_conference_category 的数据：~0 rows (大约)
DELETE FROM `kb_conference_category`;
/*!40000 ALTER TABLE `kb_conference_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conference_category` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_conference_files 结构
DROP TABLE IF EXISTS `kb_conference_files`;
CREATE TABLE IF NOT EXISTS `kb_conference_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conference_id` int(11) NOT NULL,
  `attach_name` varchar(200) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL COMMENT '1：视频，2：PDF',
  `attach_path` varchar(300) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_9` (`conference_id`),
  CONSTRAINT `FK_Reference_9` FOREIGN KEY (`conference_id`) REFERENCES `kb_conferences` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议资料';

-- 正在导出表  scyyxh_wx.kb_conference_files 的数据：~0 rows (大约)
DELETE FROM `kb_conference_files`;
/*!40000 ALTER TABLE `kb_conference_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conference_files` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_conference_guest 结构
DROP TABLE IF EXISTS `kb_conference_guest`;
CREATE TABLE IF NOT EXISTS `kb_conference_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conference_id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议嘉宾';

-- 正在导出表  scyyxh_wx.kb_conference_guest 的数据：~0 rows (大约)
DELETE FROM `kb_conference_guest`;
/*!40000 ALTER TABLE `kb_conference_guest` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conference_guest` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_conference_note 结构
DROP TABLE IF EXISTS `kb_conference_note`;
CREATE TABLE IF NOT EXISTS `kb_conference_note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conference_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `content` text,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_5` (`conference_id`),
  CONSTRAINT `FK_Reference_5` FOREIGN KEY (`conference_id`) REFERENCES `kb_conferences` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议须知';

-- 正在导出表  scyyxh_wx.kb_conference_note 的数据：~0 rows (大约)
DELETE FROM `kb_conference_note`;
/*!40000 ALTER TABLE `kb_conference_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conference_note` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_conf_plan_agenda 结构
DROP TABLE IF EXISTS `kb_conf_plan_agenda`;
CREATE TABLE IF NOT EXISTS `kb_conf_plan_agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conference_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `brief` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会议计划议程';

-- 正在导出表  scyyxh_wx.kb_conf_plan_agenda 的数据：~0 rows (大约)
DELETE FROM `kb_conf_plan_agenda`;
/*!40000 ALTER TABLE `kb_conf_plan_agenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_conf_plan_agenda` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_honored_guest 结构
DROP TABLE IF EXISTS `kb_honored_guest`;
CREATE TABLE IF NOT EXISTS `kb_honored_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `pic_url` varchar(200) DEFAULT NULL,
  `brief` varchar(400) DEFAULT NULL,
  `specification` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='协会嘉宾';

-- 正在导出表  scyyxh_wx.kb_honored_guest 的数据：~0 rows (大约)
DELETE FROM `kb_honored_guest`;
/*!40000 ALTER TABLE `kb_honored_guest` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_honored_guest` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_news_categories 结构
DROP TABLE IF EXISTS `kb_news_categories`;
CREATE TABLE IF NOT EXISTS `kb_news_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '0：正常，1：禁用',
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='新闻分类表';

-- 正在导出表  scyyxh_wx.kb_news_categories 的数据：~0 rows (大约)
DELETE FROM `kb_news_categories`;
/*!40000 ALTER TABLE `kb_news_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_news_categories` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_news_infos 结构
DROP TABLE IF EXISTS `kb_news_infos`;
CREATE TABLE IF NOT EXISTS `kb_news_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `brief` varchar(500) DEFAULT NULL,
  `content` text,
  `pic_url` varchar(200) DEFAULT NULL,
  `click_count` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '0：正常，1：禁用',
  `user_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_7` (`category_id`),
  CONSTRAINT `FK_Reference_7` FOREIGN KEY (`category_id`) REFERENCES `kb_news_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='新闻表';

-- 正在导出表  scyyxh_wx.kb_news_infos 的数据：~0 rows (大约)
DELETE FROM `kb_news_infos`;
/*!40000 ALTER TABLE `kb_news_infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_news_infos` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_roles 结构
DROP TABLE IF EXISTS `kb_roles`;
CREATE TABLE IF NOT EXISTS `kb_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- 正在导出表  scyyxh_wx.kb_roles 的数据：~0 rows (大约)
DELETE FROM `kb_roles`;
/*!40000 ALTER TABLE `kb_roles` DISABLE KEYS */;
INSERT INTO `kb_roles` (`id`, `code`, `name`, `status`) VALUES
	(1, '2', '2', 2);
/*!40000 ALTER TABLE `kb_roles` ENABLE KEYS */;

-- 导出  表 scyyxh_wx.kb_users 结构
DROP TABLE IF EXISTS `kb_users`;
CREATE TABLE IF NOT EXISTS `kb_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_name` varchar(20) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `last_login_date` varchar(20) DEFAULT NULL,
  `last_login_ip` varchar(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '0:正常，1：禁用',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_10` (`role_id`),
  CONSTRAINT `FK_Reference_10` FOREIGN KEY (`role_id`) REFERENCES `kb_roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- 正在导出表  scyyxh_wx.kb_users 的数据：~0 rows (大约)
DELETE FROM `kb_users`;
/*!40000 ALTER TABLE `kb_users` DISABLE KEYS */;
INSERT INTO `kb_users` (`id`, `login_name`, `password`, `role_id`, `email`, `mobile`, `last_login_date`, `last_login_ip`, `status`) VALUES
	(1, '2', NULL, 1, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `kb_users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
