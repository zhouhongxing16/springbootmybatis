package com.kbds.weChat.entity;

import java.util.Date;

public class Conferences {
    private Integer id;

    private String name;

    private String startDate;

    private String endDate;

    private String holdPlace;

    private String holdUnit;

    private String doUnit;

    private String assUnit;

    private String picUrl;

    private String qrcode;

    private String regStart;

    private String regEnd;

    private Integer status;

    private Integer userId;

    private Date created;

    private byte[] brief;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate == null ? null : startDate.trim();
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate == null ? null : endDate.trim();
    }

    public String getHoldPlace() {
        return holdPlace;
    }

    public void setHoldPlace(String holdPlace) {
        this.holdPlace = holdPlace == null ? null : holdPlace.trim();
    }

    public String getHoldUnit() {
        return holdUnit;
    }

    public void setHoldUnit(String holdUnit) {
        this.holdUnit = holdUnit == null ? null : holdUnit.trim();
    }

    public String getDoUnit() {
        return doUnit;
    }

    public void setDoUnit(String doUnit) {
        this.doUnit = doUnit == null ? null : doUnit.trim();
    }

    public String getAssUnit() {
        return assUnit;
    }

    public void setAssUnit(String assUnit) {
        this.assUnit = assUnit == null ? null : assUnit.trim();
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl == null ? null : picUrl.trim();
    }

    public String getQrcode() {
        return qrcode;
    }

    public void setQrcode(String qrcode) {
        this.qrcode = qrcode == null ? null : qrcode.trim();
    }

    public String getRegStart() {
        return regStart;
    }

    public void setRegStart(String regStart) {
        this.regStart = regStart == null ? null : regStart.trim();
    }

    public String getRegEnd() {
        return regEnd;
    }

    public void setRegEnd(String regEnd) {
        this.regEnd = regEnd == null ? null : regEnd.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public byte[] getBrief() {
        return brief;
    }

    public void setBrief(byte[] brief) {
        this.brief = brief;
    }
}