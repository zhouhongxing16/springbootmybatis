package com.kbds.weChat.dao;

import com.kbds.weChat.entity.ConferenceAgenda;

public interface ConferenceAgendaMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ConferenceAgenda record);

    int insertSelective(ConferenceAgenda record);

    ConferenceAgenda selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ConferenceAgenda record);

    int updateByPrimaryKey(ConferenceAgenda record);
}