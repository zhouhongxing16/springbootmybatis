package com.kbds.weChat.dao;

import com.kbds.weChat.entity.HonoredGuest;

public interface HonoredGuestMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(HonoredGuest record);

    int insertSelective(HonoredGuest record);

    HonoredGuest selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(HonoredGuest record);

    int updateByPrimaryKey(HonoredGuest record);
}