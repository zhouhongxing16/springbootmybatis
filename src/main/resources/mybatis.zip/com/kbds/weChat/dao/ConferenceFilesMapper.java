package com.kbds.weChat.dao;

import com.kbds.weChat.entity.ConferenceFiles;

public interface ConferenceFilesMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ConferenceFiles record);

    int insertSelective(ConferenceFiles record);

    ConferenceFiles selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ConferenceFiles record);

    int updateByPrimaryKey(ConferenceFiles record);
}