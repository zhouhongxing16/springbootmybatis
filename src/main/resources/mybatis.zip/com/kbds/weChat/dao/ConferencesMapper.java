package com.kbds.weChat.dao;

import com.kbds.weChat.entity.Conferences;

public interface ConferencesMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Conferences record);

    int insertSelective(Conferences record);

    Conferences selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Conferences record);

    int updateByPrimaryKeyWithBLOBs(Conferences record);

    int updateByPrimaryKey(Conferences record);
}