package com.kbds.weChat.dao;

import com.kbds.weChat.entity.ConferenceCategory;

public interface ConferenceCategoryMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ConferenceCategory record);

    int insertSelective(ConferenceCategory record);

    ConferenceCategory selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ConferenceCategory record);

    int updateByPrimaryKey(ConferenceCategory record);
}