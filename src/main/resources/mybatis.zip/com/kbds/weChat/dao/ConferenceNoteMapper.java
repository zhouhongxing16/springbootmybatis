package com.kbds.weChat.dao;

import com.kbds.weChat.entity.ConferenceNote;

public interface ConferenceNoteMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ConferenceNote record);

    int insertSelective(ConferenceNote record);

    ConferenceNote selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ConferenceNote record);

    int updateByPrimaryKeyWithBLOBs(ConferenceNote record);

    int updateByPrimaryKey(ConferenceNote record);
}