package com.kbds.weChat.dao;

import com.kbds.weChat.entity.NewsCategories;

public interface NewsCategoriesMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewsCategories record);

    int insertSelective(NewsCategories record);

    NewsCategories selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(NewsCategories record);

    int updateByPrimaryKey(NewsCategories record);
}