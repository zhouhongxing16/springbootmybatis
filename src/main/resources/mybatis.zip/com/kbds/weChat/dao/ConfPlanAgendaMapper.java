package com.kbds.weChat.dao;

import com.kbds.weChat.entity.ConfPlanAgenda;

public interface ConfPlanAgendaMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ConfPlanAgenda record);

    int insertSelective(ConfPlanAgenda record);

    ConfPlanAgenda selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ConfPlanAgenda record);

    int updateByPrimaryKey(ConfPlanAgenda record);
}