package com.kbds.weChat.dao;

import com.kbds.weChat.entity.ConferenceGuest;

public interface ConferenceGuestMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ConferenceGuest record);

    int insertSelective(ConferenceGuest record);

    ConferenceGuest selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ConferenceGuest record);

    int updateByPrimaryKey(ConferenceGuest record);
}