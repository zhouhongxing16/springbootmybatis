package com.kbds.weChat.dao;

import com.kbds.weChat.entity.NewsInfos;

public interface NewsInfosMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewsInfos record);

    int insertSelective(NewsInfos record);

    NewsInfos selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(NewsInfos record);

    int updateByPrimaryKeyWithBLOBs(NewsInfos record);

    int updateByPrimaryKey(NewsInfos record);
}